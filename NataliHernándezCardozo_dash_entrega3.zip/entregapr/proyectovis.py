
import dash
import pandas as pd
import numpy as np
import plotly.express as px
from dash import dcc
from dash import html

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
#app = dash.Dash(__name__)

pd.options.mode.chained_assignment = None  #Desactivar warnings
Base_vuelos=pd.read_csv("T_ONTIME_REPORTING.csv",
    sep=",",low_memory=False)
Base_vuelos2=Base_vuelos[["DAY_OF_MONTH","FL_DATE","ORIGIN_CITY_NAME","ORIGIN_STATE_ABR","DEST_CITY_NAME","DEST_STATE_ABR","CANCELLED","ARR_TIME","FLIGHTS","DISTANCE","CARRIER_DELAY","WEATHER_DELAY","NAS_DELAY","SECURITY_DELAY","LATE_AIRCRAFT_DELAY", "DIVERTED"]] 
Base_Alter=Base_vuelos2[(Base_vuelos2["CANCELLED"]==0) & (Base_vuelos2["DIVERTED"]==0)] 


############ Acumulado de retrasos según causa ###########

Base_causaEstado=Base_Alter[["ORIGIN_CITY_NAME","CARRIER_DELAY","WEATHER_DELAY","NAS_DELAY","SECURITY_DELAY","LATE_AIRCRAFT_DELAY"]].melt(id_vars=["ORIGIN_CITY_NAME"],var_name="Causa")
Base_causaEstado.loc[Base_causaEstado["Causa"]=="CARRIER_DELAY","Causa"]="En el operador" #*
Base_causaEstado.loc[Base_causaEstado["Causa"]=="WEATHER_DELAY","Causa"]=" Tiempo en minutos"#*
Base_causaEstado.loc[Base_causaEstado["Causa"]=="NAS_DELAY","Causa"]="Con el Sitema Aéreo Nacional"#*
Base_causaEstado.loc[Base_causaEstado["Causa"]=="SECURITY_DELAY","Causa"]="En seguridad"#*
Base_causaEstado.loc[Base_causaEstado["Causa"]=="LATE_AIRCRAFT_DELAY","Causa"]="Aeronave con tardía" #*
Causa=Base_causaEstado.groupby('Causa',as_index=False)['value'].sum().sort_values("value",ascending=False)

fig_causa=px.pie(Causa,values='value',names='Causa',
    title='Acumulado de retrasos según su causa',
    color_discrete_sequence=px.colors.sequential.RdBu)


######### Causa de retraso por top 10 ciudades de origen ##########

BasetopCiudadesretrasos=Base_causaEstado.loc[Base_causaEstado["ORIGIN_CITY_NAME"].isin(["Chicago, IL","Des Moines, IA","New York, NY","San Jose, CA","Los Angeles, CA","Aspen, CO","Dallas/Fort Worth, TX","Salt Lake City, UT","Seattle, WA"]),]
available_ciudades=BasetopCiudadesretrasos["ORIGIN_CITY_NAME"].unique() #**

TabCiudadcausaretra=BasetopCiudadesretrasos.groupby(['ORIGIN_CITY_NAME','Causa'],as_index=False)['value'].mean()

fig_retr_ciud=px.bar(TabCiudadcausaretra,x='value',y='ORIGIN_CITY_NAME',color='Causa',title='Causa retraso de llegada por top 10 de ciudades',color_discrete_sequence=px.colors.sequential.RdBu_r)

########## Distancia y tiempo de vuelo en los top 10 Estados ########

Top10estado=pd.DataFrame(Base_Alter["DEST_STATE_ABR"].value_counts(normalize=True)).sort_values(by='DEST_STATE_ABR',ascending=False).reset_index().head(10)
Top10estado.columns=["Estado_destino","Porcentaje_vuelos"]
Basetopestados=Base_Alter.loc[Base_Alter["DEST_STATE_ABR"].isin(Top10estado["Estado_destino"]),]
Basetopestados["DEST_STATE_ABR"]=pd.Categorical(Basetopestados["DEST_STATE_ABR"])
a=pd.DataFrame(Basetopestados.groupby(["DEST_STATE_ABR","DAY_OF_MONTH"],as_index=False)["FLIGHTS"].sum())
b=pd.DataFrame(Basetopestados.groupby(["DEST_STATE_ABR","DAY_OF_MONTH"],as_index=False)[["DISTANCE","ARR_TIME"]].mean())
FBase=a.merge(b,on=["DEST_STATE_ABR","DAY_OF_MONTH"],how="inner")
FBase.columns=["Estado_destino","Día_del_mes","Cantidad_vuelos","Promedio_distancia","Promedio_tiempo_vuelo"]

available_estados=FBase["Estado_destino"].unique()

fig_scatter=px.scatter(FBase,x="Promedio_distancia",y="Promedio_tiempo_vuelo",size="Cantidad_vuelos",
                       hover_name="Día_del_mes",color="Estado_destino",title="Tiempo de vuelo Vs Distancia por top 10 Estados")



########## Cantidad acumulada diaria de vuelos durante enero del 2022 en ciudades destino EEUU ########
available_day = Base_vuelos2['DAY_OF_MONTH'].unique()
@app.callback(
    dash.dependencies.Output('example-graph-1', 'figure'),
    [dash.dependencies.Input('crossfilter_day', 'value')]
    )

def update_graph(day_value):
    df_datos_day = Base_vuelos2[Base_vuelos2['DAY_OF_MONTH'] == day_value]

    viz_1 = px.treemap(df_datos_day, 
                 path=['FLIGHTS','ORIGIN_CITY_NAME']
                )
    viz_1.update_layout({
                "margin": dict(l=20, r=20, t=20, b=20),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return viz_1 

app.layout=html.Div(
    children=[
        html.H1(children="visualización de datos para los vuelos de los Estados Unidos 2022 enero.",
            style={'textAlign': 'center'}),
        
        html.H3(children="Natali Hernández Cardozo.",
            style={'textAlign': 'center'}),
        html.P(children="Descripción de la base, depuración, duplicados."),
        html.P(children="El presente conjunto de datos contiene información del desempeño y comportamiento "
        "de las compañías aéreas que operan en Estados Unidos durante el mes de enero del año de 2022. "),
        html.P(children="Fuente de datos: https://www.transtats.bts.gov/DL_SelectFields.aspx?gnoyr_VQ=FGJ&QO_fu146_anzr=. "),
        html.P(children="Se realizo mediante una limpieza de datos, la eliminación de datos duplicados, valores que se encontraran"),
        html.P(children="en los NA's (datos más conocidos como faltantes), adjuntar sus variables categóricas según gráfica se quisiera"),
        html.P(children="llevar a cabo y relacionar en su mayoría de vuelos por Ciudad de salida y llegada."),
    html.Div([
        html.Div(className='six columns'),
        html.Div([
            html.Table([
                html.Thead(html.Tr([html.Th(col) for col in Base_Alter[["ORIGIN_CITY_NAME","ORIGIN_CITY_NAME","FLIGHTS","DISTANCE","ARR_TIME"]].columns])),
                html.Tbody([html.Tr([html.Td(Base_Alter.iloc[i][col]) for col in Base_Alter[["ORIGIN_CITY_NAME","ORIGIN_CITY_NAME" ,"FLIGHTS","DISTANCE","ARR_TIME"]].columns]) for i in range(min(len(Base_Alter), 5))])
                ])], className='six columns')], className='row'),
    # 1era Viz
    html.Div([
        html.Div([
            html.H3(children="Acumulado de retrasos según causa"),
            html.P(children="Las tareas que se cumplieron al realizar esta visualización fueron analizar por causa de dificultad de los vuelos"),
            html.P(children="el comportamiento que están presentado los vuelos a sus usuarios."),
            html.P(children="Esta visualización hace uso de los canales de posición radial y tamaño, marcas de areas y el canal del color"),
            html.P(children="El insight es para poder brindarle una aseosría a la aerolínea de lo que le puede estar afectando para"),
            html.P(children="dar un óptimo servicio al usuario."),
            dcc.Graph(id='first_viz',figure=fig_causa)],className='six columns')]),
    # 2da Viz
    html.Div([
        html.Div([
            html.H3(children="Causa de retraso en top 10 ciudades de origen"),
                html.P(children='Esta visualización se desarrollo con el fin de mostrarle a la aerolínea cuanto es el tiempo de retraso que está presentando'
                    'por ciudad y en las 10 ciudades que aún és más significativa esta variable.'),
                html.P(children='Se tuvo en cuenta el orden descendente sobre el conteo de ' 
                'retrasos para la presentación de la gráfica, así mismo la variable categórica para las causas de los retrasos se diferenció usando una ' 
                'paleta de colores lo más distintos posibles entre sí. Se decide realizar un checklist por ciudad de salida, para permitir al usuario elegir las ciuades que desee'),
            html.P(children='La finalidad de esta grafica es presentar, hacer un Lookup. Identificar las causas asociadas que originaron dichos retrasos.'),
            dcc.Checklist(id='checklist_ciudad', 
                options=[{'label': i, 'value': i} for i in available_ciudades], value=["Chicago, IL","Des Moines, IA","New York, NY","San Jose, CA","Los Angeles, CA","Aspen, CO","Dallas/Fort Worth, TX","Salt Lake City, UT","Seattle, WA"],
                labelStyle={'display': 'inline-block'}),
            dcc.Graph(id='second_viz')],className='six columns')]),

        # 3ra Viz
    html.Div([
        html.Div([
            html.H3(children='Promedios entre distancia y tiempo de vuelo en los top 10 Estados '),
            html.P(children=" Está visualización tiene finalidad de identificar la cantidad total de vuelos por día del mes que estamos investigando cual es el promedio de Distancia y tiempo de vuelo en la ciudad que se seleccione"
                "dado los 10 estados más seleccionados como destino."),   
            html.P(children="Con la visualización se busca presentar y Lookup el promedio de distancia y tiempo de vuelo."),
            html.Div(children='''
            Ciudad
        '''),#
        dcc.Dropdown(
            id='crossfilter_estado',
            options=[{'label': i, 'value': i} for i in available_estados],
            value=''
        ),
        dcc.Graph(
            id='tercera_viz'
        )]),

    # 4ta Viz
    html.Div([
         html.Div([
        html.H3(children='Cantidad acumulada de vuelos diaria en el mes de enero en las ciudades origen de Estados Unidos'),
        html.P(children='El fin de la visualización es localizar cual es el día y ciudad que tienen acumulados en los Estados Unidos vuelos,' 
            'buscando, que sea de manera visible la ciudad más potencial y la de menor cantidad de vuelos'),
        html.P(children='Para destacar, se puede observar que los vuelos diarios acumulados del mes de enero del 2022 hacia algunas ciudades de ' 
            'Estados Unidos crecen a mayor ritmo que otras del mismo país.'),
        html.Div(children='''
            Día
        '''),#
        dcc.Dropdown(
            id='crossfilter_day',
            options=[{'label': i, 'value': i} for i in available_day],
            value=''
        ),
        dcc.Graph(
            id='example-graph-1'
        ), 
        ]),
    ]),
])
])
## 2da Viz

@app.callback(
    dash.dependencies.Output('second_viz', 'figure'),
    [dash.dependencies.Input('checklist_ciudad', 'value')])

def update_graph(ciudad_value):
    TabRetraso_ciudad=TabCiudadcausaretra[TabCiudadcausaretra['ORIGIN_CITY_NAME'].isin(ciudad_value)]
    fig_retr_ciud=px.bar(TabRetraso_ciudad,x='value',y='ORIGIN_CITY_NAME',color='Causa',
        title='Causa retraso de llegada por top 10 de ciudades',color_discrete_sequence=px.colors.sequential.RdBu_r)

    return fig_retr_ciud

## 3ra Viz

@app.callback(
    dash.dependencies.Output('tercera_viz', 'figure'),
    [dash.dependencies.Input('crossfilter_estado', 'value')])

def update_graph(estado_value):
    FBase_est=FBase[FBase["Estado_destino"]==estado_value]
    fig_sca=px.scatter(FBase_est,x="Promedio_distancia",y="Promedio_tiempo_vuelo",size="Cantidad_vuelos",
        hover_name="Día_del_mes",title="Tiempo de vuelo Vs Distancia por top 10 Estados destino")
    return fig_sca



if __name__ == "__main__":
    app.run_server(debug=True)